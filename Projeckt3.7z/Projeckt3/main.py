import math

z = int(input("Введите число:"))
if z > 0:
     x = ((1)/(math.pow(z,2) + 2 * z))
else:
    x = (1 - pow(z,3))
y = (2*math.pow(math.e,-3*x)-4*math.pow(x,2))/(math.log(math.fabs(x))+x)
print(y)


